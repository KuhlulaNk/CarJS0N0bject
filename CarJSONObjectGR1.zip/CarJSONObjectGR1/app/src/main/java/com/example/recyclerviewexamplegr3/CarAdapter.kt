package com.example.recyclerviewexamplegr3

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerviewexamplegr3.model.Data

class CarAdapter(private val cars: List<Data>) :
    RecyclerView.Adapter<CarAdapter.CarViewHolder>() {

    class CarViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarViewHolder {
        val tv = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_car, parent, false) as TextView
        return CarViewHolder(tv)
    }

    override fun onBindViewHolder(holder: CarViewHolder, position: Int) {
        holder.textView.text = cars[position].name
    }

    override fun getItemCount() = cars.size
}